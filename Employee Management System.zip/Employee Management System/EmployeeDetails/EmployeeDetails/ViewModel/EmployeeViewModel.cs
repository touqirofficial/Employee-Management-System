﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails.ViewModel
{
    internal class EmployeeViewModel
    {
        public int EmpId { get; set; }
        public int EmpCod { get; set; }
        public string EmpName { get; set; }
        public int PositionId { get; set; }
        public DateTime DOB { get; set; }
        public bool Status { get; set; }
        public string imagePath { get; set; }
    }
}
